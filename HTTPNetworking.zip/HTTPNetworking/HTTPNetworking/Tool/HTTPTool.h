//
//  HTTPTool.h
//  HTTPNetworking
//
//  Created by Evan on 16/7/3.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, HTTPRequestType) { // 请求类型
    HTTPRequestTypeGET = 0,
    HTTPRequestTypeHEAD,
    HTTPRequestTypePOST,
    HTTPRequestTypePUT,
    HTTPRequestTypePATCH,
    HTTPRequestTypeDELETE,
};

typedef void(^HTTPRequestSuccess)(NSURLSessionDataTask *task, id responseObject);
typedef void(^HTTPRequestFailure)(NSURLSessionDataTask *task, NSError *error);
typedef void(^HTTPRequestAllCompletion)();


@class HTTPTool;

@interface HTTPTool : NSObject

+ (HTTPTool *)defaultHTTPHelper;

/**
 *  HTTP请求
 *
 *  @param type          请求类型
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)requestType:(HTTPRequestType)type URLString:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allcompletion:(HTTPRequestAllCompletion)allCompletion;

/**
 *  GET请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)GET:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;

/**
 *  HEAD请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)HEAD:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;

/**
 *  POST请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)POST:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;

/**
 *  PUT请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)PUT:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;

/**
 *  PATCH请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)PATCH:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;
/**
 *  DELETE请求
 *
 *  @param URLString     请求路径
 *  @param parameters    请求参数
 *  @param success       成功回调
 *  @param failure       失败回调
 *  @param allCompletion 完成回调
 */
- (NSURLSessionDataTask *)DELETE:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion;

@end
