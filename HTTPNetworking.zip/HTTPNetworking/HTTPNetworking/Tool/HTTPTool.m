//
//  HTTPTool.m
//  HTTPNetworking
//
//  Created by Evan on 16/7/3.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "HTTPTool.h"
#import "AFNetworking.h"

@interface HTTPTool ()

@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation HTTPTool

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        self.manager = [AFHTTPSessionManager manager];
        
        self.manager.requestSerializer.timeoutInterval = 10;
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects: @"text/plain", @"application/json", @"text/json", @"text/javascript", @"text/html", @"image/png", nil];
        
        self.manager.responseSerializer = [AFJSONResponseSerializer serializerWithReadingOptions:NSJSONReadingAllowFragments];
    }
    return self;
}

+ (HTTPTool *)defaultHTTPHelper;
{
    static HTTPTool *instances = nil;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        
        instances = [[self alloc] init];
    });
    return instances;
}

- (NSURLSessionDataTask *)requestType:(HTTPRequestType)type URLString:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allcompletion:(HTTPRequestAllCompletion)allCompletion
{
    switch (type)
    {
        case HTTPRequestTypeGET:
            return [self GET:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
        case HTTPRequestTypeHEAD:
            return [self HEAD:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
        case HTTPRequestTypePOST:
            return [self POST:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
        case HTTPRequestTypePUT:
            return [self PUT:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
        case HTTPRequestTypePATCH:
            return [self PATCH:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
        case HTTPRequestTypeDELETE:
            return [self DELETE:URLString parameters:parameters success:success failure:failure allCompletion:allCompletion];
            
        default:
            return nil;
            break;
    }
}

- (NSURLSessionDataTask *)GET:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
       return  [self.manager GET:URLString parameters:nil progress:^(NSProgress * _Nonnull downloadProgress) {
    
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
    
            !success?:success(task,responseObject);
            !allCompletion?:allCompletion();
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    
            !failure?:failure(task,error);
            !allCompletion?:allCompletion();
        }];
}

- (NSURLSessionDataTask *)POST:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
    return [self.manager POST:URLString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        !success?:success(task,responseObject);
        !allCompletion?:allCompletion();
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        !failure?:failure(task,error);
        !allCompletion?:allCompletion();
    }];
}

- (NSURLSessionDataTask *)PATCH:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
    return [self.manager PATCH:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        !success?:success(task,responseObject);
        !allCompletion?:allCompletion();
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        !failure?:failure(task,error);
        !allCompletion?:allCompletion();
    }];
}

- (NSURLSessionDataTask *)HEAD:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
    return [self.manager HEAD:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task) {
        
        !success?:success(task,nil);
        !allCompletion?:allCompletion();
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        !failure?:failure(task,error);
        !allCompletion?:allCompletion();
    }];
}

- (NSURLSessionDataTask *)PUT:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
    return [self.manager PUT:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        !success?:success(task,nil);
        !allCompletion?:allCompletion();
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        !failure?:failure(task,error);
        !allCompletion?:allCompletion();
    }];
}

- (NSURLSessionDataTask *)DELETE:(NSString *)URLString parameters:(NSDictionary *)parameters success:(HTTPRequestSuccess)success failure:(HTTPRequestFailure)failure allCompletion:(HTTPRequestAllCompletion)allCompletion
{
    return [self.manager DELETE:URLString parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        !success?:success(task,nil);
        !allCompletion?:allCompletion();
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        !failure?:failure(task,error);
        !allCompletion?:allCompletion();
    }];
}

@end
