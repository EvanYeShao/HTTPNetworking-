//
//  ViewController.m
//  HTTPNetworking
//
//  Created by Evan on 16/7/3.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "ViewController.h"
#import "HTTPTool.h"

@interface ViewController ()

@end

@implementation ViewController

#pragma mark - Lfilecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 使用
    
    HTTPTool *httoTool = [HTTPTool defaultHTTPHelper];
    
    [httoTool requestType:HTTPRequestTypeGET URLString:@"http://news-at.zhihu.com/api/4/news/latest" parameters:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        
        NSLog(@"%@",responseObject);
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        
        NSLog(@"%@",error);
    } allcompletion:^{
        
        NSLog(@"处理所有请求完的事件");
    }];
}

@end
